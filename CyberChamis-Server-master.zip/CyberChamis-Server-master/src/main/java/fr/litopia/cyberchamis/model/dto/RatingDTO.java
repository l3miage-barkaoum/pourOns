package fr.litopia.cyberchamis.model.dto;

public class RatingDTO {
    public Integer note;
    public Integer number;
}
