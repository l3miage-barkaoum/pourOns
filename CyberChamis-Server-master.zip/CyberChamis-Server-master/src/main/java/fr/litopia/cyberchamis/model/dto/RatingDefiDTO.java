package fr.litopia.cyberchamis.model.dto;

import java.util.List;

public class RatingDefiDTO {
    public List<RatingDTO> gradeList;
    public String idDefi;
    public Integer nbTotalGrade;
}
