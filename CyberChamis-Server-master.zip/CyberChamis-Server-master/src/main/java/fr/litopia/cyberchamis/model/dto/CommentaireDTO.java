package fr.litopia.cyberchamis.model.dto;

public class CommentaireDTO {

    public String idDefi;
    public Long idUtilisateur;
    public Long idCommentaire;
    public String text;


}
