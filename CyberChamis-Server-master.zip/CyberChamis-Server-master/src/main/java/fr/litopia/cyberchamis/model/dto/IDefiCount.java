package fr.litopia.cyberchamis.model.dto;

public interface IDefiCount {
    Long getAuteurId();
    Long getCount();
}
