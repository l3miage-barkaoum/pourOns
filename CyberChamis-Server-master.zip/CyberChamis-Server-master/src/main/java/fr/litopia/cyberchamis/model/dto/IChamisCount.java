package fr.litopia.cyberchamis.model.dto;

public interface IChamisCount {
    String getIdDefi();

    Integer getCount();
}
