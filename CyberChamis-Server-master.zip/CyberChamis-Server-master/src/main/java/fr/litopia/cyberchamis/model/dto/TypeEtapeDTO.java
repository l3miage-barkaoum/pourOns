package fr.litopia.cyberchamis.model.dto;

public enum TypeEtapeDTO {
    TacheDTO,
    IndicationDTO
}
