package fr.litopia.cyberchamis.model.entity;

public enum StatutVisite {
    ENCOURS,
    ABONDON,
    FINISHED,
    PAUSE
}
