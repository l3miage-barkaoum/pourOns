package fr.litopia.cyberchamis.model.dto;

public interface ITagCount {
    String getTag();
    Integer getCount();
}
