package fr.litopia.cyberchamis.model;

import org.junit.jupiter.api.Test;

class VisiteTest {

    @Test
    void etapeSuivante() {
    }

    @Test
    void etapePrecedente() {
    }

    @Test
    void setStatut() {
    }

    @Test
    void calculPoints() {
    }
}