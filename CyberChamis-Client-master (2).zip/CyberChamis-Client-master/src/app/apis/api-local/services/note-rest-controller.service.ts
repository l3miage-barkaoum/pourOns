/* tslint:disable */
/* eslint-disable */
import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { BaseService } from '../base-service';
import { ApiConfiguration } from '../api-configuration';
import { StrictHttpResponse } from '../strict-http-response';
import { RequestBuilder } from '../request-builder';
import { Observable } from 'rxjs';
import { map, filter } from 'rxjs/operators';

import { NoteDto } from '../models/note-dto';
import { RatingDefiDto } from '../models/rating-defi-dto';

@Injectable({
  providedIn: 'root',
})
export class NoteRestControllerService extends BaseService {
  constructor(
    config: ApiConfiguration,
    http: HttpClient
  ) {
    super(config, http);
  }

  /**
   * Path part for operation getNote
   */
  static readonly GetNotePath = '/api/notes/{defiId}/{utilistateurId}';

  /**
   * This method provides access to the full `HttpResponse`, allowing access to response headers.
   * To access only the response body, use `getNote()` instead.
   *
   * This method doesn't expect any request body.
   */
  getNote$Response(params: {
    defiId: string;
    utilistateurId: number;
  }): Observable<StrictHttpResponse<NoteDto>> {

    const rb = new RequestBuilder(this.rootUrl, NoteRestControllerService.GetNotePath, 'get');
    if (params) {
      rb.path('defiId', params.defiId, {});
      rb.path('utilistateurId', params.utilistateurId, {});
    }

    return this.http.request(rb.build({
      responseType: 'json',
      accept: 'application/json'
    })).pipe(
      filter((r: any) => r instanceof HttpResponse),
      map((r: HttpResponse<any>) => {
        return r as StrictHttpResponse<NoteDto>;
      })
    );
  }

  /**
   * This method provides access to only to the response body.
   * To access the full response (for headers, for example), `getNote$Response()` instead.
   *
   * This method doesn't expect any request body.
   */
  getNote(params: {
    defiId: string;
    utilistateurId: number;
  }): Observable<NoteDto> {

    return this.getNote$Response(params).pipe(
      map((r: StrictHttpResponse<NoteDto>) => r.body as NoteDto)
    );
  }

  /**
   * Path part for operation updateNote
   */
  static readonly UpdateNotePath = '/api/notes/{defiId}/{utilistateurId}';

  /**
   * This method provides access to the full `HttpResponse`, allowing access to response headers.
   * To access only the response body, use `updateNote()` instead.
   *
   * This method sends `application/json` and handles request body of type `application/json`.
   */
  updateNote$Response(params: {
    defiId: string;
    utilistateurId: number;
    body: number
  }): Observable<StrictHttpResponse<NoteDto>> {

    const rb = new RequestBuilder(this.rootUrl, NoteRestControllerService.UpdateNotePath, 'put');
    if (params) {
      rb.path('defiId', params.defiId, {});
      rb.path('utilistateurId', params.utilistateurId, {});
      rb.body(params.body, 'application/json');
    }

    return this.http.request(rb.build({
      responseType: 'json',
      accept: 'application/json'
    })).pipe(
      filter((r: any) => r instanceof HttpResponse),
      map((r: HttpResponse<any>) => {
        return r as StrictHttpResponse<NoteDto>;
      })
    );
  }

  /**
   * This method provides access to only to the response body.
   * To access the full response (for headers, for example), `updateNote$Response()` instead.
   *
   * This method sends `application/json` and handles request body of type `application/json`.
   */
  updateNote(params: {
    defiId: string;
    utilistateurId: number;
    body: number
  }): Observable<NoteDto> {

    return this.updateNote$Response(params).pipe(
      map((r: StrictHttpResponse<NoteDto>) => r.body as NoteDto)
    );
  }

  /**
   * Path part for operation createNote
   */
  static readonly CreateNotePath = '/api/notes/';

  /**
   * This method provides access to the full `HttpResponse`, allowing access to response headers.
   * To access only the response body, use `createNote()` instead.
   *
   * This method sends `application/json` and handles request body of type `application/json`.
   */
  createNote$Response(params: {
    body: NoteDto
  }): Observable<StrictHttpResponse<NoteDto>> {

    const rb = new RequestBuilder(this.rootUrl, NoteRestControllerService.CreateNotePath, 'post');
    if (params) {
      rb.body(params.body, 'application/json');
    }

    return this.http.request(rb.build({
      responseType: 'json',
      accept: 'application/json'
    })).pipe(
      filter((r: any) => r instanceof HttpResponse),
      map((r: HttpResponse<any>) => {
        return r as StrictHttpResponse<NoteDto>;
      })
    );
  }

  /**
   * This method provides access to only to the response body.
   * To access the full response (for headers, for example), `createNote$Response()` instead.
   *
   * This method sends `application/json` and handles request body of type `application/json`.
   */
  createNote(params: {
    body: NoteDto
  }): Observable<NoteDto> {

    return this.createNote$Response(params).pipe(
      map((r: StrictHttpResponse<NoteDto>) => r.body as NoteDto)
    );
  }

  /**
   * Path part for operation getNbByValue
   */
  static readonly GetNbByValuePath = '/api/notes/{defiId}';

  /**
   * This method provides access to the full `HttpResponse`, allowing access to response headers.
   * To access only the response body, use `getNbByValue()` instead.
   *
   * This method doesn't expect any request body.
   */
  getNbByValue$Response(params: {
    defiId: string;
  }): Observable<StrictHttpResponse<RatingDefiDto>> {

    const rb = new RequestBuilder(this.rootUrl, NoteRestControllerService.GetNbByValuePath, 'get');
    if (params) {
      rb.path('defiId', params.defiId, {});
    }

    return this.http.request(rb.build({
      responseType: 'json',
      accept: 'application/json'
    })).pipe(
      filter((r: any) => r instanceof HttpResponse),
      map((r: HttpResponse<any>) => {
        return r as StrictHttpResponse<RatingDefiDto>;
      })
    );
  }

  /**
   * This method provides access to only to the response body.
   * To access the full response (for headers, for example), `getNbByValue$Response()` instead.
   *
   * This method doesn't expect any request body.
   */
  getNbByValue(params: {
    defiId: string;
  }): Observable<RatingDefiDto> {

    return this.getNbByValue$Response(params).pipe(
      map((r: StrictHttpResponse<RatingDefiDto>) => r.body as RatingDefiDto)
    );
  }

}
