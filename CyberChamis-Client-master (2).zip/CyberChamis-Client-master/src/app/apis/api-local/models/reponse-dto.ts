/* tslint:disable */
/* eslint-disable */
export interface ReponseDto {
  hasResponse?: boolean;
  id?: number;
  isCorrect?: boolean;
  nbIndicesUtilises?: number;
  numero?: number;
  reponseUtilisateur?: string;
}
