/* tslint:disable */
/* eslint-disable */
export interface ChamisCount {
  count?: number;
  idDefi?: string;
}
