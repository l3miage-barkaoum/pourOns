/* tslint:disable */
/* eslint-disable */
export interface NoteDto {
  idDefi?: string;
  idUtilisateur?: number;
  valeur?: number;
}
