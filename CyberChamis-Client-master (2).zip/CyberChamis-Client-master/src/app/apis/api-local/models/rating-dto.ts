/* tslint:disable */
/* eslint-disable */
export interface RatingDto {
  note?: number;
  number?: number;
}
