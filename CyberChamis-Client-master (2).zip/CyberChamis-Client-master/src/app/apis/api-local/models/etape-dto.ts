/* tslint:disable */
/* eslint-disable */
export interface EtapeDto {
  banner?: string;
  description?: string;
  id?: number;
  image?: string;
  nbIndices?: number;
  numero?: number;
  point?: number;
  question?: string;
  text?: string;
  titre?: string;
  type?: 'TacheDTO' | 'IndicationDTO';
  video?: string;
}
