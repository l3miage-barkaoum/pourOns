/* tslint:disable */
/* eslint-disable */
export interface IndiceDto {
  id?: number;
  indice?: string;
  numIndice?: number;
  pointsPerdus?: number;
}
