/* tslint:disable */
/* eslint-disable */
export interface ArretDto {
  codeArret?: string;
  latitude?: number;
  longitude?: number;
  nomArret?: string;
  ville?: string;
}
