/* tslint:disable */
/* eslint-disable */
import { RatingDto } from './rating-dto';
export interface RatingDefiDto {
  gradeList?: Array<RatingDto>;
  idDefi?: string;
  nbTotalGrade?: number;
}
