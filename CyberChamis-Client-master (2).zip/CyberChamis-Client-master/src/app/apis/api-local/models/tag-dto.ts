/* tslint:disable */
/* eslint-disable */
export interface TagDto {
  defiIds?: Array<string>;
  tag?: string;
}
