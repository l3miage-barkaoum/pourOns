/* tslint:disable */
/* eslint-disable */
export interface TagCount {
  count?: number;
  tag?: string;
}
