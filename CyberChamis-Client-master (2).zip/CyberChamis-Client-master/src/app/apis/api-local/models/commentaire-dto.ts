/* tslint:disable */
/* eslint-disable */
export interface CommentaireDto {
  idCommentaire?: number;
  idDefi?: string;
  idUtilisateur?: number;
  text?: string;
}
