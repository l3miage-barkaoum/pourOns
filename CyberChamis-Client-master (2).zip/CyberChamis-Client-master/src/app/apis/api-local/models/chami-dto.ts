/* tslint:disable */
/* eslint-disable */
export interface ChamiDto {
  age?: number;
  bio?: string;
  id?: number;
  idGoogle?: string;
  profileImg?: string;
  username?: string;
}
