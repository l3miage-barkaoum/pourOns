/* tslint:disable */
/* eslint-disable */
export interface DefiCount {
  auteurId?: number;
  count?: number;
}
