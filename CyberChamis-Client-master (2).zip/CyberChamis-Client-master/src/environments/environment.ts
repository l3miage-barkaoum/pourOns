// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  firebase: {
    projectId: 'grecha-b8fd9',
    appId: '1:1089985192279:web:17b61b4a2ef485fc849e12',
    storageBucket: 'grecha-b8fd9.appspot.com',
    apiKey: 'AIzaSyAZYqsY8flvZPxELejhwagkpS_qg5_OXyg',
    authDomain: 'grecha-b8fd9.firebaseapp.com',
    messagingSenderId: '1089985192279',
    measurementId: 'G-9V4330T97G',
  },
  production: false
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
