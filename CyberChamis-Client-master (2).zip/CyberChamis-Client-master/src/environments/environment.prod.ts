export const environment = {
  firebase: {
    projectId: 'grecha-b8fd9',
    appId: '1:1089985192279:web:17b61b4a2ef485fc849e12',
    storageBucket: 'grecha-b8fd9.appspot.com',
    apiKey: 'AIzaSyAZYqsY8flvZPxELejhwagkpS_qg5_OXyg',
    authDomain: 'grecha-b8fd9.firebaseapp.com',
    messagingSenderId: '1089985192279',
    measurementId: 'G-9V4330T97G',
  },
  production: true
};
